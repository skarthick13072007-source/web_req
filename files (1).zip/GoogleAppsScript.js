// ============================================================
// GOOGLE APPS SCRIPT FOR ALPHA DIGITRONIX WEBSITE
// Copy this entire code into Google Apps Script Editor
// ============================================================

const SHEET_NAME = "website leads";
const SHEET = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);

/**
 * Main POST handler for form submissions
 * Called when the HTML form sends data
 */
function doPost(e) {
  try {
    // Parse incoming JSON data
    const data = JSON.parse(e.postData.contents);
    
    // Validate required fields
    if (!data.name || !data.email || !data.phone) {
      return createErrorResponse("Missing required fields");
    }
    
    // Append data to the Google Sheet
    SHEET.appendRow([
      data.timestamp || new Date().toLocaleString('en-IN'),
      data.name,
      data.email,
      data.phone,
      data.project || "",
      data.type || "",
      data.budget || "",
      data.message || ""
    ]);
    
    // Optional: Send email notification
    sendEmailNotification(data);
    
    // Return success response
    return createSuccessResponse("Lead captured successfully");
    
  } catch (error) {
    console.error("Error in doPost:", error);
    return createErrorResponse("Server error: " + error.toString());
  }
}

/**
 * Alternative GET handler (optional)
 * For testing purposes
 */
function doGet(e) {
  return HtmlService.createHtmlOutput("Alpha Digitronix Form Handler is running ✓");
}

/**
 * Send email notification when a lead is captured
 * Edit the email address to receive notifications
 */
function sendEmailNotification(data) {
  try {
    // Change this to your email address
    const YOUR_EMAIL = "your-email@gmail.com";
    
    const subject = `New Lead: ${data.name}`;
    
    const message = `
New Lead Submission:

Name: ${data.name}
Email: ${data.email}
Phone: ${data.phone}
Project: ${data.project || "Not specified"}
Website Type: ${data.type || "Not specified"}
Budget: ${data.budget || "Not specified"}
Message: ${data.message || "No additional notes"}
Submitted: ${data.timestamp}

---
This email was sent by your Alpha Digitronix Website Form
    `;
    
    GmailApp.sendEmail(YOUR_EMAIL, subject, message);
  } catch (error) {
    console.error("Error sending email:", error);
    // Don't throw error - form should still succeed
  }
}

/**
 * Create success response
 */
function createSuccessResponse(message) {
  return ContentService.createTextOutput(JSON.stringify({
    status: "success",
    message: message
  }))
  .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Create error response
 */
function createErrorResponse(message) {
  return ContentService.createTextOutput(JSON.stringify({
    status: "error",
    message: message
  }))
  .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Utility: Format phone numbers
 * Optional - use if needed
 */
function formatPhoneNumber(phone) {
  // Remove all non-numeric characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Format as +91 XXXXX XXXXX (Indian format)
  if (cleaned.length === 10) {
    return "+91 " + cleaned.substring(0, 5) + " " + cleaned.substring(5);
  }
  return phone;
}

/**
 * Utility: Validate email
 * Optional - use if needed
 */
function validateEmail(email) {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(email);
}

/**
 * Utility: Create data backup
 * Run this monthly to backup your leads
 */
function backupLeadsData() {
  try {
    const sourceSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    const targetFolder = DriveApp.getRootFolder();
    const backupName = `website leads backup - ${new Date().toLocaleDateString()}`;
    
    // Create a copy
    SpreadsheetApp.getActiveSpreadsheet().copy(backupName);
    
    console.log("Backup created: " + backupName);
  } catch (error) {
    console.error("Backup failed:", error);
  }
}

/**
 * Utility: Get total lead count
 * Use in dashboard
 */
function getLeadCount() {
  const data = SHEET.getDataRange().getValues();
  return data.length - 1; // Subtract 1 for header row
}

/**
 * Utility: Get last 10 leads
 * Use for reporting
 */
function getRecentLeads(numberOfLeads = 10) {
  const data = SHEET.getDataRange().getValues();
  const headers = data[0];
  const recentData = data.slice(-numberOfLeads).reverse();
  
  let result = "<h2>Recent Leads</h2><table border='1'><tr>";
  
  headers.forEach(header => {
    result += "<th>" + header + "</th>";
  });
  
  result += "</tr>";
  
  recentData.forEach(row => {
    result += "<tr>";
    row.forEach(cell => {
      result += "<td>" + cell + "</td>";
    });
    result += "</tr>";
  });
  
  result += "</table>";
  
  return result;
}

/**
 * Utility: Send daily summary email
 * Can be set up as a time-triggered function
 */
function sendDailySummary() {
  try {
    const YOUR_EMAIL = "your-email@gmail.com";
    const data = SHEET.getDataRange().getValues();
    const leadsToday = data.length - 1;
    
    if (leadsToday === 0) {
      return; // No leads today
    }
    
    const subject = `Daily Summary: ${leadsToday} New Lead(s) - ${new Date().toLocaleDateString()}`;
    
    let message = `Good Morning!\n\nYou received ${leadsToday} new lead(s) today.\n\n`;
    
    if (data.length > 1) {
      const lastLead = data[data.length - 1];
      message += `Last Lead:\n`;
      message += `Name: ${lastLead[1]}\n`;
      message += `Email: ${lastLead[2]}\n`;
      message += `Phone: ${lastLead[3]}\n\n`;
    }
    
    message += `Check your Google Sheet for all leads: https://docs.google.com/spreadsheets/d/${SpreadsheetApp.getActiveSpreadsheet().getId()}\n\n`;
    message += `Best regards,\nYour Alpha Digitronix Form System`;
    
    GmailApp.sendEmail(YOUR_EMAIL, subject, message);
  } catch (error) {
    console.error("Error sending summary:", error);
  }
}

/**
 * Run this to set up daily emails
 * Execute once in Apps Script editor
 */
function setupDailyEmailTrigger() {
  // Delete existing triggers first
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(trigger => {
    if (trigger.getHandlerFunction() === 'sendDailySummary') {
      ScriptApp.deleteTrigger(trigger);
    }
  });
  
  // Create new trigger for daily at 9 AM
  ScriptApp.newTrigger('sendDailySummary')
    .timeBased()
    .everyDays(1)
    .atHour(9)
    .create();
  
  console.log("Daily email trigger set up successfully");
}

// ============================================================
// DEPLOYMENT INSTRUCTIONS
// ============================================================
/*

1. Go to your Google Sheet
2. Click Tools → Script Editor
3. Delete any existing code
4. Paste this entire script
5. Click Save (Ctrl+S)
6. Click Deploy → New Deployment
7. Select Type: "Web app"
8. Execute as: (Your email)
9. Who has access: "Anyone"
10. Click Deploy
11. Copy the Deployment URL
12. Paste into index.html where it says APPS_SCRIPT_URL

IMPORTANT SETUP STEPS:

1. Create sheet columns:
   - A: Timestamp
   - B: Name
   - C: Email
   - D: Phone
   - E: Project Name
   - F: Website Type
   - G: Budget Range
   - H: Message

2. Optional: Edit line "const YOUR_EMAIL" to receive email notifications

3. Optional: Run setupDailyEmailTrigger() to get daily summary emails

4. Test by submitting the form on your website

5. Check Google Sheet for new entries within seconds

*/
