# Alpha Digitronix Website - Google Sheets Integration Setup Guide

## Overview
This website is fully functional and responsive. To enable Google Sheets integration for lead capture, follow the steps below.

---

## Step 1: Create a Google Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Click **"+ New"** → **"Blank spreadsheet"**
3. Name it: `website leads`
4. Create the following column headers in Row 1:
   - A1: `Timestamp`
   - B1: `Name`
   - C1: `Email`
   - D1: `Phone`
   - E1: `Project Name`
   - F1: `Website Type`
   - G1: `Budget Range`
   - H1: `Message`

---

## Step 2: Set Up Google Apps Script

1. In your Google Sheet, go to **Tools** → **Script Editor**
2. Delete all existing code and paste this script:

```javascript
const SHEET_NAME = "website leads";
const SHEET = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);

function doPost(e) {
  try {
    // Parse the JSON data from the request
    const data = JSON.parse(e.postData.contents);
    
    // Append the data to the sheet
    SHEET.appendRow([
      data.timestamp,
      data.name,
      data.email,
      data.phone,
      data.project,
      data.type,
      data.budget,
      data.message
    ]);
    
    return ContentService.createTextOutput("Success").setMimeType(ContentService.MimeType.TEXT);
  } catch (error) {
    return ContentService.createTextOutput("Error: " + error.toString()).setMimeType(ContentService.MimeType.TEXT);
  }
}
```

3. Save the script (Ctrl+S or Cmd+S)
4. Click **"Deploy"** → **"New deployment"**
5. Select **Type**: "Web app"
6. Configure as:
   - Execute as: Your email
   - Who has access: "Anyone"
7. Click **"Deploy"**
8. **Copy the Web App URL** - this is important!

---

## Step 3: Update the HTML File

1. Open the `index.html` file in a text editor
2. Find this line (around line 460):
   ```javascript
   const APPS_SCRIPT_URL = 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL';
   ```
3. Replace with your actual Google Apps Script URL:
   ```javascript
   const APPS_SCRIPT_URL = 'https://script.google.com/macros/d/YOUR-SCRIPT-ID/useweb?v=1';
   ```
4. Save the file

---

## Step 4: Test the Integration

1. Open `index.html` in a web browser
2. Fill out the form with test data
3. Click "Send Project Proposal"
4. Check your Google Sheet - you should see the new entry!

---

## Features Included

✅ **Fully Responsive Design**
- Works perfectly on desktop, tablet, and mobile devices
- Mobile-first approach with flexible grid layout

✅ **Modern Dark Theme**
- Professional blue/cyan color scheme
- Glassmorphic design elements
- Smooth animations and transitions

✅ **Sticky Navigation**
- Always visible navigation bar
- Smooth scroll to sections
- Active link indicators

✅ **Hero Section**
- Eye-catching gradient text
- Call-to-action buttons
- Animated background elements

✅ **Services Section**
- 6 different service cards
- Hover animations
- Pricing information
- Quick action buttons

✅ **Lead Capture Form**
- Clean, organized form layout
- All required fields validated
- Real-time form submission
- Success/error messages
- Google Sheets integration

✅ **Testimonials**
- Client reviews with ratings
- Author information
- Professional styling

✅ **About Section**
- Company mission and vision
- Key statistics
- Professional content

✅ **Contact Section**
- Multiple contact methods
- Email, phone, WhatsApp details

✅ **Footer**
- Organized footer sections
- Social media links
- Company information
- Footer navigation

✅ **Accessibility**
- Semantic HTML
- Proper form labels
- Keyboard navigation
- Color contrast compliance

---

## Form Fields Captured

The form automatically captures:
1. **Full Name** (Required) - Client's name
2. **Email Address** (Required) - Client's email
3. **WhatsApp Number** (Required) - Client's phone
4. **Project Name** - Name of the project
5. **Website Type** - Dropdown (E-Commerce, Portfolio, Corporate, etc.)
6. **Budget Range** - Dropdown (various price ranges)
7. **Project Features & Notes** - Text area for additional details
8. **Timestamp** - Auto-added submission date/time

---

## Customization Guide

### Change Colors
Edit the CSS variables at the top of the `<style>` section:
```css
:root {
    --primary-blue: #0047ab;
    --cyan-accent: #00d2fd;
    --light-blue: #b1c5ff;
    /* ...more colors */
}
```

### Change Company Information
Search and replace:
- "Alpha Digitronix" with your company name
- Email addresses with your contact info
- Phone numbers with your details
- Service descriptions with yours

### Modify Services
Edit the services grid to change:
- Service titles
- Descriptions
- Pricing
- Number of services

### Add Your Logo
Replace the text logo with an image:
```html
<img src="your-logo.png" alt="Logo" class="logo-img">
```

### Update Hero Image
Replace the placeholder with your actual image:
```html
<img src="your-hero-image.jpg" alt="Hero" style="width: 100%; height: 100%; object-fit: cover;">
```

---

## Troubleshooting

### Form Not Submitting?
1. Check browser console (F12) for errors
2. Verify Google Apps Script URL is correct
3. Ensure CORS is enabled (using web app deployment)
4. Check network tab to see request status

### Data Not Appearing in Google Sheet?
1. Verify sheet name is exactly "website leads"
2. Check that columns match the script (Timestamp, Name, Email, etc.)
3. Verify Google Apps Script was deployed as "Web app"
4. Check script execution logs in Apps Script editor

### Mobile Layout Issues?
1. The design is fully responsive
2. If issues persist, check viewport meta tag in HTML
3. Test in different browsers

---

## Security Notes

⚠️ **Important Security Considerations:**

1. **Google Apps Script** - Your web app URL is public, so anyone can submit data (this is expected for a website form)
2. **Email Protection** - Consider not showing your actual email publicly; use contact form instead
3. **Data Validation** - The form validates required fields on the client side
4. **No Sensitive Data** - Don't ask for passwords or sensitive information

---

## Additional Features You Can Add

1. **Email Notifications** - Send yourself an email when someone submits
2. **Spam Protection** - Add reCAPTCHA to the form
3. **Form Confirmation Email** - Send a confirmation email to the user
4. **Analytics** - Track form submissions and user behavior
5. **Slack Integration** - Get notifications in Slack when leads submit

---

## Browser Support

✅ Chrome/Chromium
✅ Firefox
✅ Safari
✅ Edge
✅ Mobile browsers (iOS Safari, Chrome Mobile)

---

## Performance

- **Fully Static HTML/CSS** - No external dependencies except Google Apps Script
- **Lightweight** - Single HTML file (~50KB)
- **Fast Loading** - Optimized for web performance
- **No Build Process** - Ready to use immediately

---

## Hosting Options

You can host this website on:

1. **Netlify** (Recommended for free hosting)
   - Drag and drop HTML file
   - Automatic HTTPS
   - Custom domain support

2. **Vercel** - Similar to Netlify

3. **GitHub Pages** - Free static hosting

4. **Your Own Server** - Any web server can host static HTML

5. **Firebase Hosting** - Google's hosting service

6. **AWS S3** - Simple storage with static hosting

---

## Support & Next Steps

1. ✅ Website is fully functional
2. ✅ Form is ready for integration
3. ✅ All sections are responsive
4. 📝 Complete setup with Google Sheets in ~5 minutes

For questions or customization, refer to the inline code comments in the HTML file.

---

**Created with ❤️ by Alpha Digitronix Solutions**
